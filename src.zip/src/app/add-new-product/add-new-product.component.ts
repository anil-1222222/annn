import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Product } from '../_model/product.model';
import { ProductService } from '../_services/product.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FileHandle } from '../_model/file-handle.model';
import { DomSanitizer } from '@angular/platform-browser';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-new-product',
  templateUrl: './add-new-product.component.html',
  styleUrl: './add-new-product.component.css'
})
export class AddNewProductComponent {

  ngOnInit(){
    this.product=this.activatRoute.snapshot.data['product'];
    console.log(this.product)
  }

  constructor(private productService:ProductService,private router:Router,private sanitizer:DomSanitizer,private activatRoute:ActivatedRoute){}

  product:Product = {
    prodId: 0,
    productName: "",
    productDescription: "",
    productDiscountPrice: 0,
    productActualPrice: 0,
    productImages:[]
  }

  addNewProduct(addForm:NgForm){
    // FedEx GIX Team Member Training Plan.pptx
  const productFormData=this.prepareFormData(this.product)

    this.productService.addProduct(productFormData).subscribe(
      (response:any)=>{
        console.log(response)
        addForm.reset();
        this.product.productImages=[];
         //this.router.navigate(['/home'])
         Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Your Product has been Saved",
          showConfirmButton: false,
          timer: 3000
        });
      },
      (error:HttpErrorResponse)=>{
        console.log(error)
      }
    )
    
  }

  prepareFormData(product:Product):FormData{
    const formData=new FormData();
    formData.append('prod',new Blob([JSON.stringify(product)],{type:'application/json'}));
    
    for(var i=0;i<product.productImages.length;i++){
      formData.append('imageFile',product.productImages[i].file,product.productImages[i].file.name);
    }
  return formData
  }



  OnSelected(event:any){
    console.log(event)
    if(event.target.files){
      const file = event.target.files[0];

      const fileHandle:FileHandle = {
        file:file,
        url: this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(file))
      }
      this.product.productImages.push(fileHandle);
    }
  }

  removeImages(i:number){
     this.product.productImages.splice(i,1);
  }

  fileDropped(fileHandle:FileHandle){
      this.product.productImages.push(fileHandle);
  }

}
