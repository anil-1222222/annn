import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { UserAuthService } from '../_services/user-auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private userService:UserService,private router:Router,private userAuthService:UserAuthService){}

  login(form:NgForm){
    this.userService.login(form.value).subscribe(
      (res)=>{
        console.log(res.username)

        localStorage.setItem("user",res.username);
        this.userAuthService.setRole(res.role[0]);
        this.userAuthService.setToken(res.token);
    

        if(res.role[0]==='ADMIN'){
          Swal.fire({
            title: "Successfully Logged in as Admin✅!",
            icon: "success",
            draggable: true
          });
              this.router.navigate(['admin'])
        }else{
          Swal.fire({
            title: "Successfully Logged in as User✅!",
            icon: "success",
            draggable: true
          });
          this.router.navigate(['user'])
        }
      },
      (error)=>{
        console.log(error)
        Swal.fire({
          icon: "error",
          title: "Invalid Credentials..",
          text: "Please SignUp / Enter Correct Credentials!",
        });
      }
    )

  }



}
