import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserAuthService } from '../_services/user-auth.service';
import { ProductService } from '../_services/product.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product-view-details',
  templateUrl: './product-view-details.component.html',
  styleUrl: './product-view-details.component.css'
})
export class ProductViewDetailsComponent {
  
  product:any;
  selectedProductIndex=0
  constructor(private activateRoute:ActivatedRoute,private userAuthService:UserAuthService,private router:Router,private productService:ProductService){}
  ngOnInit(){
    this.product=  this.activateRoute.snapshot.data['product'];
    console.log(this.product)

  }
  changeIndex(i:number){
        this.selectedProductIndex=i;
  }

  
  public isAdmin(){
    return this.userAuthService.isAdmin();
  }
  public isUser(){
    return this.userAuthService.isUser();
  }

  public deleteAll(){
    this.productService.deleteAll().subscribe(
    (res:any)=>{
    console.log(res)
    }
  )
}

  buyProduct(prodId:any){
       this.router.navigate(['buyProduct',{isSingleProductCheckout:true,id:prodId}]);
  }

  addToCart(prodId:any){
    this.productService.addToCart(prodId).subscribe(
      (resp)=>{
        console.log(resp);
        Swal.fire({
          title: "Successfully Added to Cart!",
          icon: "success",
          draggable: true
        });
      },
      (error)=>{
        console.log(error);
        Swal.fire({
          title: "Hello Sir/Madam, Already You Added to cart🔕!",
          icon: "info",
          draggable: true
        });
      }
    )
  }
}
