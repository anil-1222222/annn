import { Component } from '@angular/core';
import { UserService } from '../_services/user.service';
import { UserAuthService } from '../_services/user-auth.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  constructor(private userService:UserService,private userAuthService:UserAuthService){}

  msg:string="";

  ngOnInit(){
    this.userService.forUser().subscribe(
      (res)=>{
        this.msg=res;
      },
      (error)=>{
        console.log(error)
      }
    )
  }

  public isAdmin(){
    this.userAuthService.isAdmin();
  }

}
