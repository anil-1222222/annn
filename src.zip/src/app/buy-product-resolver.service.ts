import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, MaybeAsync, Resolve, RouterStateSnapshot } from '@angular/router';
import { Product } from './_model/product.model';
import { map, Observable } from 'rxjs';
import { ProductService } from './_services/product.service';
import { ImageProcessingService } from './_services/image-processing.service';

@Injectable({
  providedIn: 'root'
})
export class BuyProductResolverService implements Resolve<Product[]> {

  constructor(private productService:ProductService,private imageProcessingService:ImageProcessingService) { }
   resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Product[]>  {
     let id= route.paramMap.get("id");
     const isSingleProductCheckout=route.paramMap.get("isSingleProductCheckout");
     return this.productService.getProductDetails(isSingleProductCheckout,id,localStorage.getItem('user'))
     .pipe(
      map((x:Product[],i)=>x.map((product:Product)=>this.imageProcessingService.createImages(product)))
    )
  }
}
