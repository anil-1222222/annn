import { Injectable } from '@angular/core';
import { ProductService } from './product.service';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { map, Observable, of } from 'rxjs';
import { Product } from '../_model/product.model';
import { ImageProcessingService } from './image-processing.service';

@Injectable({
  providedIn: 'root'
})
export class ProductResolveService implements Resolve<Product> {

  constructor(private productService:ProductService,private imageProcessingService:ImageProcessingService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Product> {
   let id= route.paramMap.get("prodId");
   if(id){
  //then we ve to fetch details from backend
       return this.productService.getProductById(id)
       .pipe(map(p=>this.imageProcessingService.createImages(p)));
   }
   else{
      return of(this.getProductDetails());
   }
  }

  getProductDetails(){
    return {
      prodId:0,
      productName:" ",
      productDescription:" ",
      productDiscountPrice:0,
      productActualPrice:0,
      productImages:[]
    }

  }
}
