import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from '../_model/product.model';
import { Observable } from 'rxjs';
import { OrderDetails } from '../_model/order-details.model';
import { MyOrderDetails } from '../_model/order.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private httpClient:HttpClient) { }

  PATH_OF_API="http://localhost:8080";
  public addProduct(product:FormData):Observable<any>{
    console.log(product)
    return this.httpClient.post<any>(this.PATH_OF_API+"/product/addNewProduct",product);
  }

  public getAllProducts(pageNumber:any,searchKeyWord:string=""){
    return this.httpClient.get<Product[]>(this.PATH_OF_API+"/product/products?pageNumber="+pageNumber+"&searchKey="+searchKeyWord);
  }

  public deleteProduct(prodId:number){
    return this.httpClient.delete<Product>(this.PATH_OF_API+"/product/delete/"+prodId);
  }

  public getProductById(productId:any){
    return this.httpClient.get<Product>("http://localhost:8080/product/getProductById/"+productId);
  }

  public getProductDetails(isSingleProductCheckout:any,prodId:any,username:any){
       return this.httpClient.get<Product[]>("http://localhost:8080/product/getProductDetails/"+isSingleProductCheckout+"/"+prodId+"/"+username);
  }

  public placeOrder(orderDetails:OrderDetails,isCartCheckOut:any){
    return this.httpClient.post("http://localhost:8080/order/placeOrder/"+isCartCheckOut,orderDetails);
  }


  public addToCart(prodId:any){
    return this.httpClient.get("http://localhost:8080/cart/getToCart/"+prodId+"/"+localStorage.getItem('user'));
  }

  public getCartDetails(username:any){
    return this.httpClient.get("http://localhost:8080/cart/cartDetails/"+username);
  }

  public deleteCartById(prodId:any){
    return this.httpClient.delete("http://localhost:8080/cart/delete/"+prodId);
  }
  public deleteAll(){
    return this.httpClient.delete("http://localhost:8080/cart/deleteAll");
  }

  public getMyOrders():Observable<MyOrderDetails[]>{
    return this.httpClient.get<MyOrderDetails[]>("http://localhost:8080/order/getOrderDetails/"+localStorage.getItem('user'))
  }

  public getAllOrders(status:any):Observable<MyOrderDetails[]>{
    return this.httpClient.get<MyOrderDetails[]>("http://localhost:8080/order/getOrders/"+status)
  }

  public markAsDelivered(prodId:any){
    return this.httpClient.get("http://localhost:8080/order/markOrderAsDelivered/"+prodId);
  }

  public createTransaction(amount:any){
    return this.httpClient.get("http://localhost:8080/order/createTransaction/"+amount)
  }
}
