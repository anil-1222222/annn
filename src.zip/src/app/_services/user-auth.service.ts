import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor() { }

  public setRole(role:string){
    localStorage.setItem("role",role);
  }

  public getRole(){
    return localStorage.getItem("role");
  }
  public setToken(token:string){
    localStorage.setItem("token",token);
  }

  public getToken(){
    return localStorage.getItem("token");
  }

  public clear(){
    return localStorage.clear();
  }

  public isLoggedin(){
    return this.getRole() && this.getToken();
  }

  public isAdmin(){
    const role:any=this.getRole();
    return role==="ADMIN";
    
  }

  public isUser(){
    const role:any=this.getRole();
    return role==="USER";
    
  }

  public setUsername(username:string){
    localStorage.setItem("username",username);
  }
  public getUsername(){
    return localStorage.getItem("username");
  }
}
