import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserAuthService } from './user-auth.service';

@Injectable({
  providedIn: 'root'
})



export class UserService {

  constructor(private httpClient:HttpClient,private userAuthService:UserAuthService) { }

  PATH_OF_API="http://localhost:8080";

  requestHeaders=new HttpHeaders({"No-Auth":"True"})

public login(data:any):Observable<any>{
      return  this.httpClient.post(this.PATH_OF_API +"/user/token",data,{headers:this.requestHeaders});
  }

  public roleMatch(role:string){
    let isMatch=false;
    if(this.userAuthService.getRole()!=null){
        if(role===this.userAuthService.getRole())
           isMatch=true;
          return isMatch;
        }
        else{
          return isMatch;
        }
  }

  public register(data:any):Observable<any>{
    return this.httpClient.post("http://localhost:8080/user/register",data,{headers:this.requestHeaders})
  }

  public forUser(){
    //start chrome --disable-web-security --user-data-dir="C:\chrome_dev"
    return this.httpClient.get(this.PATH_OF_API+'/user/user',{responseType:'text'})
  }

  public forAdmin(){
    return this.httpClient.get(this.PATH_OF_API+'/user/admin',{responseType:'text'})
  }
}
