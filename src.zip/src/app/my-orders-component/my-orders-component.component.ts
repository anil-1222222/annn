import { Component } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { MyOrderDetails } from '../_model/order.model';

@Component({
  selector: 'app-my-orders-component',
  templateUrl: './my-orders-component.component.html',
  styleUrl: './my-orders-component.component.css'
})
export class MyOrdersComponentComponent {

  displayedColumns: string[] = ['Name','Address','Contact No','Amount','Status']
  myOrderDetails:MyOrderDetails[]=[];
  constructor(private productService:ProductService){}

  ngOnInit(){
    this.getOrderDetails();
  }

  getOrderDetails(){
    this.productService.getMyOrders().subscribe(
      (res:MyOrderDetails[])=>{
        console.log(res);
        this.myOrderDetails=res;
      },
      (error)=>{
        console.log(error);
      }
    )
  }
}
