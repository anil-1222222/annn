import { Component } from '@angular/core';
import { Product } from '../_model/product.model';
import { ProductService } from '../_services/product.service';
import { map } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { ImageProcessingService } from '../_services/image-processing.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  pageNumber:number=0;

  showLoadButton=false;
  productDetails:Product[]=[];
  constructor(private productService:ProductService,private imageProcessingService:ImageProcessingService,private router:Router){}

  ngOnInit(){
    this.getAllProducts();
  }
  
    public getAllProducts(searchKey:string=""){
      this.productService.getAllProducts(this.pageNumber,searchKey)
      .pipe(map((x:Product[],i)=>x.map((product:Product)=>this.imageProcessingService.createImages(product))))
      .subscribe(
        (res:Product[])=>{
               console.log(res);
            if(res.length==8){
              this.showLoadButton=true;
            }else{
              this.showLoadButton=false;
            }
            res.forEach(p=>this.productDetails.push(p));
               //this.productDetails=res;
        },
        (error:HttpErrorResponse)=>{
          console.log(error)
        }
      )
    }

    showProductDetails(productId:number){
         this.router.navigate(['/productViewDetails',{prodId:productId}]);
    }

    loadMoreProduct(){
      this.pageNumber =this.pageNumber+1;
      this.getAllProducts();
    }


    searchByKeyword(search:any){
      this.pageNumber=0;
      this.productDetails=[];
      this.getAllProducts(search);
   }
}
