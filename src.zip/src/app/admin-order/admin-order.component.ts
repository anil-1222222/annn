import { Component } from '@angular/core';
import { MyOrderDetails } from '../_model/order.model';
import { ProductService } from '../_services/product.service';

@Component({
  selector: 'app-admin-order',
  templateUrl: './admin-order.component.html',
  styleUrl: './admin-order.component.css'
})
export class AdminOrderComponent {

  status:string="All";
  
    displayedColumns: string[] = ['Name','Address','Contact No','Amount','Status','Action']
    myOrderDetails:MyOrderDetails[]=[];
    constructor(private productService:ProductService){}
  
    ngOnInit(){
      this.getOrderDetails(this.status);
    }
  
    getOrderDetails(statusParameter:string){
      this.productService.getAllOrders(statusParameter).subscribe(
        (res:MyOrderDetails[])=>{
          console.log(res);
          this.myOrderDetails=res;
        },
        (error)=>{
          console.log(error);
        }
      )
    }

    markAsDelivered(orderId:any){
        this.productService.markAsDelivered(orderId).subscribe(
          (res)=>{
            console.log(res);
            this.getOrderDetails(this.status)
          },
          (error)=>{
            console.log(error);
          }
        )
    }
}
