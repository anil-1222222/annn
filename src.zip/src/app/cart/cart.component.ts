import { Component } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { UserAuthService } from '../_services/user-auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {

  displayedColumns: string[] = ['Name','Description','Price','DiscountedPrice','Delete']
  cartDetails=[];

  constructor(private productService:ProductService,private userAuthService:UserAuthService,private router:Router){}

  ngOnInit(){
    this.getCartDetails();
  }
  getCartDetails(){
    this.productService.getCartDetails(localStorage.getItem('user')).subscribe(
      (res:any)=>{
        console.log(res);
        this.cartDetails=res;
      },
      (error)=>{
        console.log(error)
      }
    )
  }

  checkOut(){
    // this.productService.getProductDetails(false,0,localStorage.getItem('user')).subscribe(
    //   (res)=>{
    //     console.log(res);
    //   },
    //   (error)=>{
    //     console.log(error);
    //   }
    // )

    this.router.navigate(['buyProduct',{isSingleProductCheckout:false,id:0}]);
  }

  deleteCart(prodId:any){
    Swal.fire({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Yes, delete it!"
        }).then((result) => {
          if (result.isConfirmed) {
            this.productService.deleteCartById(prodId).subscribe(
              (res)=>{
                console.log(res);
                this.getCartDetails();
              },
              (error)=>{
                console.log(error);
              }
            )
            Swal.fire({
              title: "Deleted!",
              text: "Your Product has been deleted.",
              icon: "success"
            });
          }
        });

  }
}
