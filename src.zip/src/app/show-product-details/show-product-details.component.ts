import { Component } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { Product } from '../_model/product.model';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';
import { ShowProductImagesDialogComponent } from '../show-product-images-dialog/show-product-images-dialog.component';
import { ImageProcessingService } from '../_services/image-processing.service';
import { map } from 'rxjs';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-show-product-details',
  templateUrl: './show-product-details.component.html',
  styleUrl: './show-product-details.component.css'
})
export class ShowProductDetailsComponent {

  pageNumber:number=0;
  showLoadButton=false;

  constructor(private productService:ProductService,private router:Router,public imageDialog:MatDialog,private imageProcessingService:ImageProcessingService){}
  productDetails:Product[]=[];
  displayedColumns: string[] = ['Product Id', 'Product Name', 'Product Description', 'Product Discounted Price','Product Actual Price','Images','Edit','Delete'];
  ngOnInit(){
    this.getAllProducts();
  }

  public getAllProducts(searchKey:string=""){
    this.productService.getAllProducts(this.pageNumber,searchKey)
    .pipe(
      map((x:Product[],i)=>x.map((product:Product)=>this.imageProcessingService.createImages(product)))
    )
    .subscribe(
      (res:Product[])=>{
             console.log(res);
             if(res.length==8){
              this.showLoadButton=true;
            }else{
              this.showLoadButton=false;
            }
            this.productDetails=res;
        //res.forEach(p=>this.productDetails.push(p))
      },
      (error:HttpErrorResponse)=>{
        console.log(error)
      }
    )
  }
  deleteProduct(id:number){
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.productService.deleteProduct(id).subscribe(
          (res:any)=>{
          this.getAllProducts();
          },
           (error:HttpErrorResponse)=>{
                 console.log(error)
         }
        )
        Swal.fire({
          title: "Deleted!",
          text: "Your Product has been deleted.",
          icon: "success"
        });
      }
    });

  }

  showImages(product:Product){
     this.imageDialog.open(ShowProductImagesDialogComponent,{
       data:{images:product.productImages},
       height:'500px',
       width:'800px'
     })
}

  editProductDetails(productId:number){
    this.router.navigate(['/addNewProduct',{prodId:productId}]);
  }

  loadMoreProduct(){
    this.pageNumber =this.pageNumber+1;
    this.getAllProducts();
  }

  searchByKeyword(search:any){
    this.pageNumber=0;
    this.productDetails=[];
    this.getAllProducts(search);
 }
}
