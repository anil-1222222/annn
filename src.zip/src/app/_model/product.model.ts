import { FileHandle } from "./file-handle.model";

export interface Product {
    prodId: number,
    productName: string,
    productDescription: String,
    productDiscountPrice: number,
    productActualPrice: number,
    productImages:FileHandle[]
}