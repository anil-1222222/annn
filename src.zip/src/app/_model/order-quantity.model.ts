export interface OrderQuantity{
    "prodId":number,
    "quantity":number
}