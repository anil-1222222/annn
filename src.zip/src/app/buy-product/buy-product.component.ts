import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { OrderDetails } from '../_model/order-details.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../_model/product.model';
import { ProductService } from '../_services/product.service';

declare var Razorpay:any;
@Component({
  selector: 'app-buy-product',
  templateUrl: './buy-product.component.html',
  styleUrl: './buy-product.component.css'
})
export class BuyProductComponent {

  constructor(private activatedRoute:ActivatedRoute,private productService:ProductService,private router:Router){

  }

  productDetails:Product[]=[];
  orderDetails:OrderDetails={
    fullName:'',
    fullAddress:'',
    contactNumber:'',
    alternateContactNumber:'',
    orderProductQuantityList:[]
  }

  isSingleProductCheckout:any=false;
  ngOnInit(){
   this.productDetails= this.activatedRoute.snapshot.data['productDetails'];

   this.isSingleProductCheckout =this.activatedRoute.snapshot.paramMap.get("isSingleProductCheckout");

   this.productDetails.forEach(
    x=> this.orderDetails.orderProductQuantityList.push(
      {prodId: x.prodId,quantity:1}
    )
   );
   console.log(this.productDetails);
   console.log(this.orderDetails);
  }
  placeOrder(form:NgForm){
    this.productService.placeOrder(this.orderDetails,this.isSingleProductCheckout).subscribe(
      (resp)=>{
        console.log(resp);
        form.reset();
        this.router.navigate(['orderConfirm']);

      },
      (error)=>{
        console.log(error)
      }
    )
  }

  getQuantityForProduct(prodId:any){
   const filteredProduct= this.orderDetails.orderProductQuantityList.filter(
      (productQuantity)=>productQuantity.prodId===prodId
    );
   return filteredProduct[0].quantity;
  }

  getCalculatedTotal(prodId:any,productDiscountPrice:any){
    const filteredProduct= this.orderDetails.orderProductQuantityList.filter(
      (productQuantity)=>productQuantity.prodId===prodId
    );
    return filteredProduct[0].quantity * productDiscountPrice;
  }

  onQuantityChanged(quantity:any,prodId:any){
    this.orderDetails.orderProductQuantityList.filter(
      (orderProduct)=>orderProduct.prodId===prodId
    )[0].quantity=quantity;
  }
  getClaculatedGrandTotal(){
    let grandTotal=0;
    this.orderDetails.orderProductQuantityList.forEach(
      (productQuantity)=>{
       const price= this.productDetails.filter(product=>product.prodId===productQuantity.prodId)[0].productDiscountPrice;
      grandTotal=grandTotal+ price*productQuantity.quantity;
      }
    );
    return grandTotal;
  }

  createTransactionAndPlaceOrder(orderForm:NgForm){
    this.productService.createTransaction(this.getClaculatedGrandTotal()).subscribe(
      (res)=>{
        console.log(res);
      this.openTransactionModel(res);
      this.placeOrder(orderForm);
      },
      (error)=>{
        console.log(error);
      }
    )
  }
  openTransactionModel(response:any){
    var option={
       order_id:response.orderId,
       key_id:response.key,
       amount:response.amount,
       currency:response.currency,
       name:'Anil Kumar N',
       description:'Payment of online shopping',
       image:'assets/ansol.jfif',
       handler:(response:any)=>{
          this.processResponse(response);
       },
       prefill:{
        name:'Anil Kumar N',
        email:'anil@gmail.com',
        contact:'6363069552'
       },
       notes:{
        address:'Online Shopping'
       },
       theme:{
        color:'#f37254'
       }
    };
   var razorPay= new Razorpay(option);
   razorPay.open();
  }

  processResponse(resp:any){
    console.log(resp);
    this.router.navigate(['orderConfirm']);
  }
}
