import { Component } from '@angular/core';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { UserAuthService } from '../_services/user-auth.service';
import { NgForm } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  
    constructor(private userService:UserService,private router:Router,private userAuthService:UserAuthService){}
  
    register(form:NgForm){
      this.userService.register(form.value).subscribe(
        (res)=>{
          console.log(res)
          Swal.fire({
                      title: res.username+" Registered Successfully✅!",
                      icon: "success",
                      draggable: true
                    });
          this.router.navigate(['/']);
        },
        (error)=>{
          console.log(error)
        }
      )
    }

}
