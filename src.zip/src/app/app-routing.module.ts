import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { LoginComponent } from './login/login.component';
import { authGuard } from './_auth/auth.guard';
import { AddNewProductComponent } from './add-new-product/add-new-product.component';
import { ShowProductDetailsComponent } from './show-product-details/show-product-details.component';
import { ProductResolveService } from './_services/product-resolve.service';
import { ProductViewDetailsComponent } from './product-view-details/product-view-details.component';
import { BuyProductComponent } from './buy-product/buy-product.component';
import { BuyProductResolverService } from './buy-product-resolver.service';
import { OrderConfirmationComponent } from './order-confirmation/order-confirmation.component';
import { RegisterComponent } from './register/register.component';
import { CartComponent } from './cart/cart.component';
import { MyOrdersComponentComponent } from './my-orders-component/my-orders-component.component';
import { AdminOrderComponent } from './admin-order/admin-order.component';

const routes: Routes = [
  {path:"home",component:HomeComponent},
  {path:"admin",component:AdminComponent,canActivate:[authGuard],data:{role:'ADMIN'}},
  {path:"user",component:UserComponent,canActivate:[authGuard],data:{role:'USER'}},
  {path:"forbidden",component:ForbiddenComponent},
  {path:"login",component:LoginComponent},
  {path:"",redirectTo:"login",pathMatch:"full"},
  {path:"addNewProduct",component:AddNewProductComponent,canActivate:[authGuard],data:{role:'ADMIN'},resolve:{product:ProductResolveService}},
  {path:"showProductDetails",component:ShowProductDetailsComponent,canActivate:[authGuard],data:{role:'ADMIN'}},
  {path:"productViewDetails",component:ProductViewDetailsComponent,resolve:{product:ProductResolveService}},
  {path:"buyProduct",component:BuyProductComponent,canActivate:[authGuard],data:{role:'USER'},resolve:{productDetails:BuyProductResolverService}},
  {path:"orderConfirm",component:OrderConfirmationComponent,canActivate:[authGuard],data:{role:'USER'}},
  {path:"login/register",component:RegisterComponent},
  {path:"cart",component:CartComponent,canActivate:[authGuard],data:{role:'USER'}},
  {path:"myOrders",component:MyOrdersComponentComponent,canActivate:[authGuard],data:{role:'USER'}},
  {path:"adminOrders",component:AdminOrderComponent,canActivate:[authGuard],data:{role:'ADMIN'}}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
