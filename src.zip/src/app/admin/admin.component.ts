import { Component } from '@angular/core';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {

  constructor(private userService:UserService){}
  
    msg:string="";
  
    ngOnInit(){
      this.userService.forAdmin().subscribe(
        (res)=>{
          this.msg=res;
        },
        (error)=>{
          console.log(error)
        }
      )
    }
}
